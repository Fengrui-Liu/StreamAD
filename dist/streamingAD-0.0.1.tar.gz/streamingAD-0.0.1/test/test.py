#!/usr/bin/env python
# coding=utf-8
"""
Author: liufr
Github: https://github.com/Fengrui-Liu
LastEditTime: 2020-11-21 10:52:30
Copyright 2020 liufr
Description: 
"""
import json
import numpy as np
import sys
import os
# temporary solution for relative imports in case pyod is not installed
# if pyod is installed, no need to use the following line
sys.path.append(
    os.path.abspath(os.path.join(os.path.dirname("__file__"), '..')))



import streamingAD.window as window

np.random.seed(0)
n = 8
d = 3
X = np.random.randn(n, d)
Z = np.copy(X)
Z[90:, :] = 1


print(X)
print("----")


def test_window_slide():
    """
    docstring
    """
    data = window.tumble(X,11,drop=False)
    # for index, point in enumerate(data):
    #     print(point)
    for point in data:
        print(point)
    # step_1 = next(data)
    # print(step_1)



if __name__ == "__main__":
    test_window_slide()